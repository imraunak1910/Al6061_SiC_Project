Al6061-SiC project paper file mapping

The uploaded project ZIP was inspected and its data/Paper_Index_v5.csv was used as the project’s current source of truth for paper IDs, citations, DOI, disposition and row counts.

The second uploaded ZIP contained exactly 20 PDFs. DOI strings were extracted from each PDF's first pages and matched against the v5 Paper_Index. All 20 PDFs matched a Paper_ID in the index (including P01 and P04; the other original-collection records use U01-U20 IDs).

papers_renamed/ contains copies of the original PDFs renamed as:
PaperID_CitationSlug.pdf

No original PDF content was edited. Original filenames are preserved in the Excel and CSV mapping.

The workbook contains:
- 20_PDF_Mapping: the exact 20 file-to-paper matches, DOI read from PDF, existing disposition, reason, v5 row count, page count, source URL.
- Full_V5_Paper_Index: all 37 records in the project Paper_Index_v5.csv, including additional literature entries not present in the 20-PDF ZIP.
- Project_File_Inventory: files found in the uploaded v5 project ZIP.

Important:
- Paper IDs are taken from the uploaded project's Paper_Index_v5.csv. Do not assume Uxx is a training ID; it is an index ID.
- This task maps files to paper IDs; it does not re-audit all paper science or verify every extracted measurement.
- A paper with zero v5 rows may still have a PDF present; check its disposition and reason in the index.
